let canvas = document.getElementById('hello-world-canvas')
let context = canvas.getContext('2d')

context.fillStyle = "blue";
context.fillRect(10, 40, 30, 70);

context.fillStyle = "yellow"
context.fillRect(50, 30, 60, 60);

